"use client";

/**
 * ImagePropertiesControls — Phase 2, Agent A
 * --------------------------------------------
 *
 * Properties panel for an active Fabric Image. Provides:
 *   • A "Swap photo" thumbnail grid wired to listing.photos[] (up to 5)
 *   • An object-fit toggle (cover / contain / stretch)
 *   • Corner radius slider
 *   • Opacity slider
 *
 * Photo swapping uses `img.setSrc(url, { crossOrigin: "anonymous" })` per the
 * Fabric v6 API. After load, we re-apply the object-fit scaling against the
 * new natural dimensions so the user doesn't see a sudden zoom/crop change.
 *
 * Corner radius is implemented via a Rect clipPath on the image — matching
 * the approach used in CanvasEditor.tsx's createFabricImage factory. We
 * REPLACE the clipPath on each change rather than mutating an existing one
 * because the clip dimensions depend on the image's natural width/height.
 */

import { FabricImage, Rect } from "fabric";
import type { Canvas } from "fabric";

import {
  fitImageInFrame,
  frameOfImage,
  focalOfImage,
  type FrameRect,
} from "../../fabric-factory";
import {
  type ChangeEvent,
  type JSX,
  useCallback,
  useEffect,
  useState,
} from "react";

import type { MLSListingPayload } from "../../types";

interface ImagePropertiesControlsProps {
  canvas: Canvas | null;
  listing: MLSListingPayload | null;
  selectionVersion: number;
  onCanvasMutated?: () => void;
  recordHistory?: () => void;
}

/**
 * Local mirror of the active Image's editable state.
 */
interface ImageState {
  /** Current src URL — used to highlight the active thumbnail in the swap grid. */
  src: string;
  /** Derived object-fit setting. We persist this as image meta on a custom prop. */
  objectFit: "cover" | "contain" | "stretch";
  /** Corner radius in display px. */
  cornerRadius: number;
  /** 0..1 opacity from Fabric. */
  opacity: number;
  /**
   * The image's CURRENT displayed dimensions (= naturalDim * scale). These
   * are what the user sees on screen RIGHT NOW. Distinct from box dims
   * (below) because the displayed image may overflow / be letterboxed
   * inside the box depending on object-fit.
   */
  targetWidth: number;
  targetHeight: number;
  /**
   * The image layer's BOX dimensions — what the template author specified
   * (or what the user has resized to). Object-fit math runs against THIS,
   * not the displayed dims. Read from the Fabric object's data bag and
   * falls back to displayed dims for pre-fix images.
   *
   * Why this exists: prior to 2026-05-23, the code derived "target" dims
   * from naturalDim × scale, which meant Cover/Contain/Stretch always
   * computed scale = currentScale (no-op). Tracking the box separately
   * breaks the circular reference.
   */
  boxWidth: number;
  boxHeight: number;
  /** Natural image dimensions — used when computing the new scale on fit change. */
  naturalWidth: number;
  naturalHeight: number;
  /**
   * The FRAME rect in canvas px — the visible window the photo is cropped to
   * (the absolutePositioned clipPath). This is what the X/Y/W/H steppers edit.
   * Reads from the clip when present, else from the displayed bounds.
   */
  frameLeft: number;
  frameTop: number;
  frameWidth: number;
  frameHeight: number;
}

const FIT_OPTIONS: ReadonlyArray<{
  value: ImageState["objectFit"];
  label: string;
}> = [
  { value: "cover", label: "Cover" },
  { value: "contain", label: "Contain" },
  { value: "stretch", label: "Stretch" },
];

/**
 * Read the image's natural dimensions out of its underlying HTMLImageElement.
 * Fabric exposes the element via `.getElement()`. When the element is a video
 * or canvas (Fabric.Image accepts both), we fall back to `width`/`height` on
 * the FabricImage itself.
 */
function readNaturalSize(img: FabricImage): {
  naturalWidth: number;
  naturalHeight: number;
} {
  // why: getElement() can return an HTMLImageElement | HTMLVideoElement |
  // HTMLCanvasElement. Only HTMLImageElement carries naturalWidth/Height.
  const el = img.getElement?.();
  if (el && el instanceof HTMLImageElement) {
    return {
      naturalWidth: el.naturalWidth || img.width || 1,
      naturalHeight: el.naturalHeight || img.height || 1,
    };
  }
  return {
    naturalWidth: img.width || 1,
    naturalHeight: img.height || 1,
  };
}

/**
 * Read our custom `objectFit` metadata off the image. We stamp this on the
 * Fabric object's `data` bag at swap-time so the panel can recover the user's
 * intent on re-select (Fabric doesn't natively persist object-fit — it only
 * tracks the resulting scaleX/scaleY).
 */
function readObjectFit(img: FabricImage): ImageState["objectFit"] {
  const data = (img as unknown as { data?: { objectFit?: string } }).data;
  const fit = data?.objectFit;
  if (fit === "contain" || fit === "stretch") return fit;
  return "cover";
}

function writeObjectFit(img: FabricImage, fit: ImageState["objectFit"]): void {
  // why: preserve existing data fields (layerId, layerKind, displayName).
  // Without this we'd nuke the metadata that the layer panel relies on.
  const obj = img as unknown as { data?: Record<string, unknown> };
  obj.data = { ...(obj.data ?? {}), objectFit: fit };
}

/**
 * Read the layer's BOX dimensions (independent of current scale).
 *
 * Returns the values stamped by `createFabricImage`'s data bag. Falls back
 * to the image's CURRENT displayed dimensions for pre-2026-05-23 images
 * (autosave snapshots etc. that don't carry targetBoxWidth/Height). The
 * fallback is intentionally lossy — old images won't see Cover/Contain/
 * Stretch do anything until the user re-creates them — but it's better
 * than crashing the panel.
 */
function readBoxDims(img: FabricImage): {
  boxWidth: number;
  boxHeight: number;
} {
  const data = (
    img as unknown as {
      data?: { targetBoxWidth?: number; targetBoxHeight?: number };
    }
  ).data;
  const bw = typeof data?.targetBoxWidth === "number" ? data.targetBoxWidth : null;
  const bh = typeof data?.targetBoxHeight === "number" ? data.targetBoxHeight : null;
  if (bw && bh && bw > 0 && bh > 0) {
    return { boxWidth: bw, boxHeight: bh };
  }
  // Fallback: derive from current displayed dims. Lossy but safe.
  const { naturalWidth, naturalHeight } = readNaturalSize(img);
  const scaleX = img.scaleX ?? 1;
  const scaleY = img.scaleY ?? 1;
  return {
    boxWidth: naturalWidth * scaleX,
    boxHeight: naturalHeight * scaleY,
  };
}

/**
 * Write box dims back to the data bag — preserves all other data-bag
 * fields. Called when the user resizes via Fabric handles (orchestrator
 * picks up the change via object:modified) so the box follows the image.
 */
export function writeBoxDims(img: FabricImage, w: number, h: number): void {
  const obj = img as unknown as { data?: Record<string, unknown> };
  obj.data = {
    ...(obj.data ?? {}),
    targetBoxWidth: Math.max(1, w),
    targetBoxHeight: Math.max(1, h),
  };
}

/**
 * Read the corner radius back from the image's clipPath, if one exists.
 * Returns 0 when the image has no clipPath (i.e., square corners).
 *
 * As of 2026-05-23 the clipPath is absolutePositioned (canvas px) so rx
 * is already in display px — no scale math needed. We still divide by
 * scaleX as a fallback for legacy images created with the old
 * image-local clip pattern, so the slider position doesn't lie on
 * historic content.
 */
function readCornerRadius(img: FabricImage): number {
  const clip = img.clipPath;
  if (!clip || !(clip instanceof Rect)) return 0;
  const rx = clip.rx ?? 0;
  const absolute =
    (clip as unknown as { absolutePositioned?: boolean }).absolutePositioned ??
    false;
  if (absolute) return Math.round(rx);
  // Legacy fallback — clip is image-local, scale back to display px.
  const scaleX = img.scaleX ?? 1;
  return Math.round(rx * scaleX);
}

/**
 * Read the image's FRAME rect (canvas px) — the clipPath window the photo is
 * cropped to. This is the rect the X/Y/W/H steppers operate on. Falls back to
 * the image's displayed bounds when there's no Rect clip.
 */
function readFrameRect(img: FabricImage): FrameRect {
  // Native crop: the object's bounding box IS the visible frame.
  return frameOfImage(img);
}

/**
 * Read the current image state out of the canvas. Returns null when there's
 * no active object or the active object isn't a FabricImage.
 */
function readImageState(canvas: Canvas | null): ImageState | null {
  if (!canvas) return null;
  const active = canvas.getActiveObject();
  if (!active || !(active instanceof FabricImage)) return null;
  const { naturalWidth, naturalHeight } = readNaturalSize(active);
  // Native crop: the visible box IS the bounding box (frame). All "box"/
  // "target" dims derive from it so the circle detection + readouts are honest.
  const frame = readFrameRect(active);
  return {
    src: active.getSrc?.() ?? "",
    objectFit: readObjectFit(active),
    cornerRadius: readCornerRadius(active),
    opacity: typeof active.opacity === "number" ? active.opacity : 1,
    targetWidth: frame.width,
    targetHeight: frame.height,
    boxWidth: frame.width,
    boxHeight: frame.height,
    naturalWidth,
    naturalHeight,
    frameLeft: frame.left,
    frameTop: frame.top,
    frameWidth: frame.width,
    frameHeight: frame.height,
  };
}

/**
 * Compute the scaleX/scaleY pair that satisfies the requested object-fit
 * against the current target box. Mirrors the math in CanvasEditor's
 * createFabricImage factory.
 */
function computeFitScale(
  fit: ImageState["objectFit"],
  targetWidth: number,
  targetHeight: number,
  naturalWidth: number,
  naturalHeight: number,
): { scaleX: number; scaleY: number } {
  const cover = Math.max(
    targetWidth / naturalWidth,
    targetHeight / naturalHeight,
  );
  const contain = Math.min(
    targetWidth / naturalWidth,
    targetHeight / naturalHeight,
  );
  if (fit === "stretch") {
    return {
      scaleX: targetWidth / naturalWidth,
      scaleY: targetHeight / naturalHeight,
    };
  }
  if (fit === "contain") {
    return { scaleX: contain, scaleY: contain };
  }
  return { scaleX: cover, scaleY: cover };
}

/**
 * Apply (or remove) a rounded-corner radius on the image's BOX clipPath.
 *
 * As of 2026-05-23 the image ALWAYS has a clipPath at its box dimensions
 * (added by `createFabricImage`). We never delete that clipPath — even at
 * radius=0 we keep the rect clip so Cover overflow continues to be clipped
 * to the layer's box. Setting radius=0 just gives square corners.
 *
 * Why we rebuild the Rect rather than mutating in place: Fabric's clipPath
 * rendering caches geometry; reassigning `img.clipPath` invalidates the
 * cache reliably across all Fabric v6 versions. Mutating rx/ry on the
 * existing Rect sometimes leaves a stale-render until the next redraw.
 */
function applyCornerRadius(img: FabricImage, radius: number): void {
  // Native crop: the visible frame IS the bounding box. A rounding clipPath is
  // only needed when radius > 0; at radius 0 we remove it (square corners, no
  // clip — the crop already bounds the photo).
  if (!radius || radius <= 0) {
    img.clipPath = undefined;
    return;
  }
  const box = frameOfImage(img);
  img.clipPath = new Rect({
    left: box.left,
    top: box.top,
    width: box.width,
    height: box.height,
    rx: radius,
    ry: radius,
    originX: "left",
    originY: "top",
    absolutePositioned: true,
  });
}

/**
 * Resize the image's bounding box to a perfect square using the shorter of
 * the current target width/height. Recomputes scaleX/scaleY against the
 * object-fit so the photo crops to the square cleanly. Returns the new
 * side length in display px — callers pass this to applyCornerRadius to
 * achieve a perfect circle (radius = side / 2).
 */
function resizeToSquare(img: FabricImage, fit: ImageState["objectFit"]): number {
  // Square the frame to the shorter side, keeping the top-left, and re-cover.
  const box = frameOfImage(img);
  const side = Math.min(box.width, box.height);
  const focal = focalOfImage(img);
  fitImageInFrame(
    img,
    { left: box.left, top: box.top, width: side, height: side },
    fit,
    focal.focalX,
    focal.focalY,
  );
  return side;
}

/**
 * One-shot "make it a circle" — squares the bounding box, then applies a
 * half-dimension clipPath so the result is a perfect circle regardless of
 * the source photo's aspect ratio.
 */
function applyCircleShape(img: FabricImage, fit: ImageState["objectFit"]): void {
  const side = resizeToSquare(img, fit);
  applyCornerRadius(img, side / 2);
}

/**
 * Detect whether the image currently reads as a circle: bounding box is
 * approximately square AND the corner radius is at least half the shorter
 * side. We use a 2px tolerance on the square check because float scaling
 * can drift the displayed box by a fraction of a pixel after several edits.
 */
function isCircleShape(state: ImageState): boolean {
  const dim = Math.min(state.targetWidth, state.targetHeight);
  const squareEnough = Math.abs(state.targetWidth - state.targetHeight) < 2;
  const roundEnough = state.cornerRadius >= dim / 2 - 1;
  return squareEnough && roundEnough && dim > 0;
}

/**
 * Size + position an image to fill a target frame rect (canvas px), honoring
 * object-fit, then rebuild its absolutePositioned clipPath at that frame.
 *
 * Mirrors createFabricImage's cover/contain placement — including the slight
 * above-center focal bias for real-estate exteriors — so the on-canvas result
 * matches what the render pipeline produces. Deliberately does NOT fire
 * `object:modified`: callers sync history via recordHistory() (same pattern as
 * handleFitChange). Firing object:modified would invoke the editor's clip
 * rebuild, which assumes displayed-bounds == box and would re-balloon a Cover
 * photo back out of the frame we just set.
 */
function fitImageToFrame(
  img: FabricImage,
  frame: FrameRect,
  fit: ImageState["objectFit"],
): void {
  const focal = focalOfImage(img);
  fitImageInFrame(img, frame, fit, focal.focalX, focal.focalY);
  repinRoundClip(img);
}

/** Re-pin a rounding clipPath (if any) to the image's current bounding box. */
function repinRoundClip(img: FabricImage): void {
  const clip = img.clipPath instanceof Rect ? img.clipPath : null;
  if (!clip) return;
  const box = frameOfImage(img);
  const rx = typeof clip.rx === "number" ? clip.rx : 0;
  img.clipPath = new Rect({
    left: box.left,
    top: box.top,
    width: box.width,
    height: box.height,
    rx,
    ry: rx,
    originX: "left",
    originY: "top",
    absolutePositioned: true,
  });
}

/**
 * Find the open rectangle the image should fill: full canvas width, and the
 * vertical span between the nearest wide BAND above and the nearest wide BAND
 * below the image. "Bands" are non-text objects spanning ≥60% of the canvas
 * width (e.g. the header + info bands). Text and narrow accents are ignored so
 * a wide headline isn't mistaken for a band. Falls back to the canvas top /
 * bottom edge when there's no band on that side.
 */
function computeOpenSpace(
  canvas: Canvas,
  img: FabricImage,
): { left: number; top: number; width: number; height: number } {
  const cw = canvas.width ?? 1080;
  const ch = canvas.height ?? 1080;
  const box = frameOfImage(img);
  const centerY = box.top + box.height / 2;
  const WIDE = cw * 0.6;
  let gapTop = 0;
  let gapBottom = ch;
  for (const o of canvas.getObjects()) {
    if (o === img) continue;
    const tp = (o as unknown as { type?: string }).type ?? "";
    if (tp.includes("text")) continue; // skip headlines/labels
    const br = o.getBoundingRect();
    if (br.width < WIDE) continue; // not a full-width band
    const oTop = br.top;
    const oBottom = br.top + br.height;
    // nearest band whose bottom sits above the image center → gap ceiling
    if (oBottom <= centerY && oBottom > gapTop) gapTop = oBottom;
    // nearest band whose top sits below the image center → gap floor
    if (oTop >= centerY && oTop < gapBottom) gapBottom = oTop;
  }
  return {
    left: 0,
    top: gapTop,
    width: cw,
    height: Math.max(1, gapBottom - gapTop),
  };
}

export default function ImagePropertiesControls(
  props: ImagePropertiesControlsProps,
): JSX.Element {
  const {
    canvas,
    listing,
    selectionVersion,
    onCanvasMutated,
    recordHistory,
  } = props;
  const [state, setState] = useState<ImageState | null>(() =>
    readImageState(canvas),
  );
  /** Tracks an in-flight swap so the user can't double-click two thumbs and race FabricImage.fromURL. */
  const [isSwapping, setIsSwapping] = useState<boolean>(false);

  useEffect(() => {
    setState(readImageState(canvas));
  }, [canvas, selectionVersion]);

  /**
   * Swap the active image's underlying source to a new listing photo URL.
   * Uses Fabric v6's `setSrc` — replaces the image's underlying element
   * in place, preserving position/angle/zIndex/clipPath structure. After
   * load we recompute the scale to honor the current objectFit.
   */
  const handleSwapPhoto = useCallback(
    async (nextUrl: string): Promise<void> => {
      if (!canvas || isSwapping) return;
      const active = canvas.getActiveObject();
      if (!active || !(active instanceof FabricImage)) return;
      if (nextUrl === state?.src) return;

      setIsSwapping(true);
      try {
        // why: crossOrigin: "anonymous" is mandatory — without it the new
        // image taints the canvas and toDataURL throws SecurityError on
        // export. See ImageLayer typedoc + CanvasEditor.tsx createFabricImage.
        // Capture the frame + fit + focal BEFORE the swap (focal is derived
        // from the OLD photo's crop), then re-frame the new photo into the
        // same frame so it lands at the same on-screen size + framing.
        const currentFit = readObjectFit(active);
        const frame = frameOfImage(active);
        const focal = focalOfImage(active);
        await active.setSrc(nextUrl, { crossOrigin: "anonymous" });
        fitImageInFrame(active, frame, currentFit, focal.focalX, focal.focalY);

        // Re-apply rounding so rounded photos stay rounded after the swap.
        applyCornerRadius(active, state?.cornerRadius ?? 0);

        canvas.requestRenderAll();
        onCanvasMutated?.();
        recordHistory?.();
        setState(readImageState(canvas));
      } catch (err) {
        // why: failed swap is non-fatal — log and bail. The user sees the
        // existing image and can try another thumbnail. A toast system would
        // belong in the orchestrator, not in a leaf control.
        console.error("Image swap failed:", err);
      } finally {
        setIsSwapping(false);
      }
    },
    [canvas, isSwapping, onCanvasMutated, recordHistory, state],
  );

  /**
   * Change the object-fit. Recomputes the scale and writes the new fit into
   * the image's `data` bag so it survives re-select.
   */
  const handleFitChange = useCallback(
    (next: ImageState["objectFit"]): void => {
      if (!canvas || !state) return;
      const active = canvas.getActiveObject();
      if (!active || !(active instanceof FabricImage)) return;
      // Re-frame into the CURRENT frame (bounding box) under the new fit,
      // preserving the focal point. Native crop sets cropX/cropY/width/height.
      const frame = frameOfImage(active);
      const focal = focalOfImage(active);
      fitImageInFrame(active, frame, next, focal.focalX, focal.focalY);
      writeObjectFit(active, next);
      // Re-pin the rounding clip (if any) to the new box.
      applyCornerRadius(active, state.cornerRadius);
      canvas.requestRenderAll();
      onCanvasMutated?.();
      recordHistory?.();
      // why: re-read from canvas so targetWidth/Height reflect the new
      // scaled dimensions in the local mirror. boxWidth/Height stay the
      // same; this just refreshes the displayed-dims half.
      setState(readImageState(canvas));
    },
    [canvas, onCanvasMutated, recordHistory, state],
  );

  /**
   * Edit one field of the frame rect (X/Y/W/H) from the numeric steppers.
   * Re-fits the photo into the new frame so Cover/Contain stays correct. The
   * spinner arrows + keyboard up/down nudge by `step`, so the author can creep
   * a value to perfect without retyping. History is committed on blur.
   */
  const handleFrameEdit = useCallback(
    (field: "left" | "top" | "width" | "height", value: number): void => {
      if (!canvas || !state) return;
      const active = canvas.getActiveObject();
      if (!active || !(active instanceof FabricImage)) return;
      if (!Number.isFinite(value)) return;
      const cur = readFrameRect(active);
      const next = {
        ...cur,
        [field]:
          field === "width" || field === "height"
            ? Math.max(1, value)
            : value,
      };
      fitImageToFrame(active, next, state.objectFit);
      canvas.requestRenderAll();
      onCanvasMutated?.();
      setState(readImageState(canvas));
      // why: defer recordHistory to onBlur so a burst of arrow-key nudges
      // collapses into one undo step instead of dozens.
    },
    [canvas, onCanvasMutated, state],
  );

  const handleFrameCommit = useCallback(() => {
    recordHistory?.();
  }, [recordHistory]);

  /**
   * Fill the open space: resize + reposition the active image to the gap
   * between the bands above and below it, full canvas width. One click for the
   * common "snap the hero photo flush between the header and info bands" task.
   */
  const handleFitToOpenSpace = useCallback((): void => {
    if (!canvas || !state) return;
    const active = canvas.getActiveObject();
    if (!active || !(active instanceof FabricImage)) return;
    const frame = computeOpenSpace(canvas, active);
    fitImageToFrame(active, frame, state.objectFit);
    canvas.requestRenderAll();
    onCanvasMutated?.();
    recordHistory?.();
    setState(readImageState(canvas));
  }, [canvas, onCanvasMutated, recordHistory, state]);

  const handleShapeCircle = useCallback((): void => {
    if (!canvas || !state) return;
    const active = canvas.getActiveObject();
    if (!active || !(active instanceof FabricImage)) return;
    applyCircleShape(active, state.objectFit);
    canvas.requestRenderAll();
    onCanvasMutated?.();
    recordHistory?.();
    // why: re-read from canvas so targetWidth/Height + cornerRadius reflect
    // the squared-up box. The "Circle" pill now shows as active.
    setState(readImageState(canvas));
  }, [canvas, onCanvasMutated, recordHistory, state]);

  const handleShapeRect = useCallback((): void => {
    if (!canvas || !state) return;
    const active = canvas.getActiveObject();
    if (!active || !(active instanceof FabricImage)) return;
    // why: clear the clip but leave the bounding box where the user has it
    // — if they squared it intentionally for a circular crop and then
    // changed their mind, they probably still want a square. They can resize
    // by handle if they want a different aspect ratio.
    applyCornerRadius(active, 0);
    canvas.requestRenderAll();
    onCanvasMutated?.();
    recordHistory?.();
    setState({ ...state, cornerRadius: 0 });
  }, [canvas, onCanvasMutated, recordHistory, state]);

  const handleCornerRadiusChange = useCallback(
    (e: ChangeEvent<HTMLInputElement>): void => {
      if (!canvas || !state) return;
      const active = canvas.getActiveObject();
      if (!active || !(active instanceof FabricImage)) return;
      const next = Number(e.target.value);
      if (!Number.isFinite(next)) return;
      applyCornerRadius(active, next);
      canvas.requestRenderAll();
      onCanvasMutated?.();
      setState({ ...state, cornerRadius: next });
      // why: continuous slider — defer recordHistory to mouseup commit.
    },
    [canvas, onCanvasMutated, state],
  );

  const handleCornerRadiusCommit = useCallback(() => {
    recordHistory?.();
  }, [recordHistory]);

  const handleOpacityChange = useCallback(
    (e: ChangeEvent<HTMLInputElement>): void => {
      if (!canvas || !state) return;
      const active = canvas.getActiveObject();
      if (!active || !(active instanceof FabricImage)) return;
      // why: panel shows 0..100, Fabric uses 0..1. Convert at the boundary.
      const pct = Number(e.target.value);
      if (!Number.isFinite(pct)) return;
      const next = pct / 100;
      active.set({ opacity: next });
      canvas.requestRenderAll();
      onCanvasMutated?.();
      setState({ ...state, opacity: next });
    },
    [canvas, onCanvasMutated, state],
  );

  const handleOpacityCommit = useCallback(() => {
    recordHistory?.();
  }, [recordHistory]);

  if (!state) {
    return (
      <div className="px-4 py-6 text-sm text-[var(--studio-text-muted)]">
        Select an image layer to edit its properties.
      </div>
    );
  }

  // why: listing.photos is the source of truth for the swap grid. We cap at 5
  // because the canvas-editor schema only binds hero_photo + photo_2..5.
  const photoOptions = listing?.photos?.slice(0, 5) ?? [];
  const hasListing = listing !== null;

  return (
    <div className="flex flex-col gap-4 px-3 py-3">
      {/* ===== Swap photo ===== */}
      <Section title="Swap Photo">
        {!hasListing ? (
          <p className="text-xs text-[var(--studio-text-muted)]">
            No listing attached — photo swap unavailable.
          </p>
        ) : photoOptions.length === 0 ? (
          <p className="text-xs text-[var(--studio-text-muted)]">
            This listing has no photos.
          </p>
        ) : (
          <div className="grid grid-cols-5 gap-1.5">
            {photoOptions.map((url, idx) => {
              const isCurrent = url === state.src;
              return (
                <button
                  key={`${url}_${idx}`}
                  type="button"
                  onClick={() => void handleSwapPhoto(url)}
                  disabled={isSwapping}
                  aria-label={`Use photo ${idx + 1}`}
                  title={`Photo ${idx + 1}`}
                  className={`group relative aspect-square overflow-hidden rounded-md border transition-all disabled:opacity-50 ${
                    isCurrent
                      ? "border-gold-500 ring-2 ring-gold-500/40"
                      : "border-[var(--studio-border)] hover:border-white/30"
                  }`}
                >
                  {/*
                    why: native <img>, not next/image. The Fabric layer also
                    uses raw browser images, so any CDN quirks (CORS headers,
                    redirects) surface here AT THUMB-TIME instead of after the
                    user clicks. Cheaper debugging cost.
                  */}
                  <img
                    src={url}
                    alt={`Photo ${idx + 1}`}
                    crossOrigin="anonymous"
                    className="h-full w-full object-cover"
                  />
                  {isCurrent ? (
                    <span className="absolute inset-x-0 bottom-0 bg-gold-500 py-0.5 text-center text-[8px] font-bold uppercase text-white">
                      Current
                    </span>
                  ) : null}
                </button>
              );
            })}
          </div>
        )}
        {isSwapping ? (
          <p className="mt-2 text-[10px] text-[var(--studio-text-muted)]">
            Swapping photo…
          </p>
        ) : null}
      </Section>

      {/* ===== Object fit ===== */}
      <Section title="Fit">
        <div className="grid grid-cols-3 gap-1">
          {FIT_OPTIONS.map((opt) => {
            const isActive = state.objectFit === opt.value;
            return (
              <button
                key={opt.value}
                type="button"
                onClick={() => handleFitChange(opt.value)}
                className={`rounded-md border px-2 py-1.5 text-xs font-medium transition-colors ${
                  isActive
                    ? "border-gold-500 bg-[var(--studio-active)] text-gold-300"
                    : "border-[var(--studio-border)] bg-[var(--studio-input-bg)] text-white hover:bg-[var(--studio-hover)]"
                }`}
              >
                {opt.label}
              </button>
            );
          })}
        </div>
      </Section>

      {/* ===== Position & Size ===== */}
      <Section title="Position & Size">
        <button
          type="button"
          onClick={handleFitToOpenSpace}
          title="Resize this photo to fill the open space between the bands above and below it"
          className="flex w-full items-center justify-center gap-1.5 rounded-md border border-[var(--studio-border)] bg-[var(--studio-input-bg)] px-2 py-1.5 text-xs font-medium text-white transition-colors hover:border-gold-500 hover:bg-[var(--studio-hover)]"
        >
          <FitGlyph />
          Fit to open space
        </button>
        {/* why: native number inputs carry their own spinner arrows and respond
            to keyboard up/down, so each value can be nudged 1px at a time to
            land a perfect fit. W/H resize the frame (photo re-fits Cover); X/Y
            move it. */}
        <div className="mt-2 grid grid-cols-2 gap-2">
          <StepperField
            label="X"
            value={Math.round(state.frameLeft)}
            onChange={(v) => handleFrameEdit("left", v)}
            onCommit={handleFrameCommit}
          />
          <StepperField
            label="Y"
            value={Math.round(state.frameTop)}
            onChange={(v) => handleFrameEdit("top", v)}
            onCommit={handleFrameCommit}
          />
          <StepperField
            label="W"
            value={Math.round(state.frameWidth)}
            min={1}
            onChange={(v) => handleFrameEdit("width", v)}
            onCommit={handleFrameCommit}
          />
          <StepperField
            label="H"
            value={Math.round(state.frameHeight)}
            min={1}
            onChange={(v) => handleFrameEdit("height", v)}
            onCommit={handleFrameCommit}
          />
        </div>
      </Section>

      {/* ===== Shape (Rectangle / Circle) =====
          why: one-click circle for agent headshots + co-brand marks. The
          freeform Corner Radius slider below still works for soft-rounded
          cards (e.g. 16-24px) — Shape is the preset for "perfect circle". */}
      <Section title="Shape">
        <div className="grid grid-cols-2 gap-1">
          {(
            [
              { value: "rect", label: "Rectangle", onClick: handleShapeRect },
              { value: "circle", label: "Circle", onClick: handleShapeCircle },
            ] as const
          ).map((opt) => {
            const isCircle = isCircleShape(state);
            const isActive =
              (opt.value === "circle" && isCircle) ||
              (opt.value === "rect" && !isCircle);
            return (
              <button
                key={opt.value}
                type="button"
                onClick={opt.onClick}
                aria-pressed={isActive}
                className={`flex items-center justify-center gap-1.5 rounded-md border px-2 py-1.5 text-xs font-medium transition-colors ${
                  isActive
                    ? "border-gold-500 bg-[var(--studio-active)] text-gold-300"
                    : "border-[var(--studio-border)] bg-[var(--studio-input-bg)] text-white hover:bg-[var(--studio-hover)]"
                }`}
              >
                {opt.value === "circle" ? <CircleGlyph /> : <RectGlyph />}
                {opt.label}
              </button>
            );
          })}
        </div>
      </Section>

      {/* ===== Corner radius ===== */}
      <Section title="Corner Radius">
        <div className="flex items-center gap-2">
          <input
            type="number"
            value={state.cornerRadius}
            min={0}
            max={200}
            onChange={handleCornerRadiusChange}
            onBlur={handleCornerRadiusCommit}
            className="w-20 rounded-md border border-[var(--studio-input-border)] bg-[var(--studio-input-bg)] px-2 py-1 text-sm text-white focus:border-gold-500 focus:outline-none focus:ring-1 focus:ring-gold-500/40"
          />
          <input
            type="range"
            min={0}
            max={200}
            value={state.cornerRadius}
            onChange={handleCornerRadiusChange}
            onMouseUp={handleCornerRadiusCommit}
            onTouchEnd={handleCornerRadiusCommit}
            className="flex-1 accent-gold-500"
          />
        </div>
      </Section>

      {/* ===== Opacity ===== */}
      <Section title="Opacity">
        <div className="flex items-center gap-2">
          <input
            type="number"
            value={Math.round(state.opacity * 100)}
            min={0}
            max={100}
            onChange={handleOpacityChange}
            onBlur={handleOpacityCommit}
            className="w-20 rounded-md border border-[var(--studio-input-border)] bg-[var(--studio-input-bg)] px-2 py-1 text-sm text-white focus:border-gold-500 focus:outline-none focus:ring-1 focus:ring-gold-500/40"
          />
          <input
            type="range"
            min={0}
            max={100}
            value={Math.round(state.opacity * 100)}
            onChange={handleOpacityChange}
            onMouseUp={handleOpacityCommit}
            onTouchEnd={handleOpacityCommit}
            className="flex-1 accent-gold-500"
          />
          <span className="w-8 text-right text-xs text-[var(--studio-text-muted)]">
            {Math.round(state.opacity * 100)}%
          </span>
        </div>
      </Section>
    </div>
  );
}

// ===========================================================================
// Section subcomponent
// ===========================================================================

interface SectionProps {
  title: string;
  children: React.ReactNode;
}

function Section(props: SectionProps): JSX.Element {
  return (
    <div>
      <div className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-[var(--studio-text-muted)]">
        {props.title}
      </div>
      {props.children}
    </div>
  );
}

// ===========================================================================
// Shape glyphs — small line-art icons for the segmented control buttons
// ===========================================================================

/**
 * A labeled numeric stepper. Wraps a native <input type="number"> so it keeps
 * the browser's built-in up/down spinner arrows and arrow-key nudging. Emits
 * onChange on each value change and onCommit on blur (history checkpoint).
 */
interface StepperFieldProps {
  label: string;
  value: number;
  min?: number;
  step?: number;
  onChange: (value: number) => void;
  onCommit?: () => void;
}

function StepperField(props: StepperFieldProps): JSX.Element {
  const { label, value, min, step = 1, onChange, onCommit } = props;
  return (
    <label className="flex items-center gap-1.5">
      <span className="w-4 text-[10px] font-semibold uppercase text-[var(--studio-text-muted)]">
        {label}
      </span>
      <input
        type="number"
        value={value}
        min={min}
        step={step}
        onChange={(e) => {
          const v = Number(e.target.value);
          if (Number.isFinite(v)) onChange(v);
        }}
        onBlur={onCommit}
        className="w-full rounded-md border border-[var(--studio-input-border)] bg-[var(--studio-input-bg)] px-2 py-1 text-sm text-white focus:border-gold-500 focus:outline-none focus:ring-1 focus:ring-gold-500/40"
      />
    </label>
  );
}

function FitGlyph(): JSX.Element {
  return (
    <svg
      width="14"
      height="14"
      viewBox="0 0 16 16"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M2 5.5V2.5H5M11 2.5H14V5.5M14 10.5V13.5H11M5 13.5H2V10.5" />
    </svg>
  );
}

function RectGlyph(): JSX.Element {
  return (
    <svg
      width="14"
      height="14"
      viewBox="0 0 16 16"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      aria-hidden="true"
    >
      <rect x="2.5" y="2.5" width="11" height="11" rx="1.5" />
    </svg>
  );
}

function CircleGlyph(): JSX.Element {
  return (
    <svg
      width="14"
      height="14"
      viewBox="0 0 16 16"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      aria-hidden="true"
    >
      <circle cx="8" cy="8" r="5.5" />
    </svg>
  );
}
