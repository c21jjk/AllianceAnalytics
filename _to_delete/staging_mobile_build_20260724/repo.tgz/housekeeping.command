#!/bin/bash
# One-time housekeeping pass.
# Removes the stale .git/index.lock left over from earlier sandbox attempts,
# untracks build artifacts, deletes the stray ~/package-lock.json,
# and commits the new .gitignore + package-lock.json + next.config.ts changes.

set -e
cd "/Users/johnkoch/Documents/GitHub/AllianceAnalytics" || exit 1

echo "─── Removing stale git index lock (if any) ───"
[ -f .git/index.lock ] && rm -f .git/index.lock && echo "  deleted .git/index.lock" || echo "  (no stale lock)"

echo "─── Removing stray ~/package-lock.json (Next.js was picking it as workspace root) ───"
if [ -f "$HOME/package-lock.json" ]; then
    rm -f "$HOME/package-lock.json" && echo "  deleted $HOME/package-lock.json"
else
    echo "  (no stray file at $HOME/package-lock.json)"
fi

echo "─── Untracking build artifacts that were committed historically ───"
git rm --cached -q next-env.d.ts 2>/dev/null && echo "  untracked next-env.d.ts" || echo "  (next-env.d.ts already untracked)"
git rm --cached -q tsconfig.tsbuildinfo 2>/dev/null && echo "  untracked tsconfig.tsbuildinfo" || echo "  (tsconfig.tsbuildinfo already untracked)"

echo "─── Staging real changes ───"
git add .gitignore package-lock.json next.config.ts

echo "─── Committing ───"
git commit -m "Add .gitignore, lock deps, fix next.config.ts

- Add .gitignore (Next.js standard): node_modules, .env*.local, .next/,
  build artifacts, vercel, etc.
- Commit package-lock.json for reproducible installs.
- next.config.ts: remove deprecated experimental.typedRoutes; add
  outputFileTracingRoot to keep Next.js from picking up stray
  package-lock.json files higher up the tree.
- Untrack auto-generated next-env.d.ts and tsconfig.tsbuildinfo
  (regenerated on build; covered by new .gitignore)."

echo
echo "─── Final state ───"
git log --oneline -3
echo
git status

echo
echo "✓ Housekeeping done. Press Cmd+W or close this Terminal window."
