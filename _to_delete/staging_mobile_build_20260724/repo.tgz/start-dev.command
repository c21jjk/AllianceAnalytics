#!/bin/bash
# Double-click this file to start the AllianceAnalytics dev server.
# Once it says "Ready in X.Xs", visit http://localhost:3000 in your browser.
# To stop the server: press Ctrl+C in this Terminal window, or just close it.

cd "/Users/johnkoch/Documents/GitHub/AllianceAnalytics" || exit 1
echo "Starting AllianceAnalytics dev server..."
echo "Once you see 'Ready', open http://localhost:3000"
echo ""
npm run dev
